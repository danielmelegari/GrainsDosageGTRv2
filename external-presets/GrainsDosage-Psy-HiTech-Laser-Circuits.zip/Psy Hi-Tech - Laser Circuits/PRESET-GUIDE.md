# Psy Hi-Tech - Laser Circuits

12 individually authored effect presets for GrainsDosage 0.13.22.
Suggested tempo: 175–200 BPM.

All enabled modules with a Mix control use 100%; disabled module mixes are 0%. Master mix is 100%. Filter and Gater have no separate mix. No modulation targets any mix. Limiter enabled at -6 dBFS.

Use on a separate synth/percussion/FX track, preferably with a dry source and some headroom. These process incoming audio; they do not generate a forest or laser sound from silence. Avoid the kick/bass bus for the first audition. Let audio play for a bar to fill the buffers. Pitches depend on your source.

The rhythm masks, LFO waves, rates and pitch phrases are authored, not randomized. Granular scheduling and Reslice retain their inherent engine behavior; fixed Reslice seeds/ranges constrain their variation.

## 01 Falling Laser

One-beat falling pitch sweep of +/-18 semitones plus a falling resonant peak.

Source: Sustained saw or bright FM tone. Grain: 18 ms; density 20; pitch 12 semitones. Filter: Resonant Peak, 3400 Hz.

## 02 Needle Burst

Thirty-second-note needle gates and sixty-fourth-note answers.

Source: Bright FM stab or metallic tick. Grain: 15 ms; density 26; pitch 24 semitones. Filter: Northern VA, 6200 Hz.

## 03 Binary Teeth

Alternating binary gates with short repeat cuts; no random probability.

Source: Dry midrange synth loop. Grain: 21 ms; density 22; pitch 0 semitones. Filter: Notch, 3200 Hz.

## 04 Chrome Rail

Tight metallic comb ring with a bounded quarter-beat comb-frequency sweep.

Source: Broadband transient or short saw stab. Grain: 25 ms; density 18; pitch 7 semitones. Filter: Comb +, 784 Hz.

## 05 Triplet Ricochet

Programmed triplet repeat lengths; every fourth step answers one octave up.

Source: Dry tonal stab loop. Grain: 20 ms; density 18; pitch 12 semitones. Filter: Resonant Peak, 2800 Hz.

## 06 Octave Circuit

Fixed sixteen-step pitch phrase: root, octave, fifth and two octaves.

Source: Single-note saw or FM loop. Grain: 28 ms; density 16; pitch 0 semitones. Filter: Transistor Ladder, 4200 Hz.

## 07 Reverse Voltage

Reverse cut bursts through a negative comb; fixed reverse setting and source area.

Source: Short metallic or FM loop. Grain: 35 ms; density 14; pitch 12 semitones. Filter: Comb -, 1046.5 Hz.

## 08 Data Splinters

Fixed 10-bit/12 kHz cut texture, short gates and bounded two-repeat fragments.

Source: Noisy FM or percussion loop. Grain: 17 ms; density 24; pitch 7 semitones. Filter: Low + Band, 4600 Hz.

## 09 Alien Syllables

Fast A-vowel articulation with timed holes and phrase-end repetitions.

Source: Bright FM phrase or dry vocal. Grain: 22 ms; density 19; pitch 12 semitones. Filter: Formant A, 1800 Hz.

## 10 Rising Railgun

Half-beat rising pitch and resonant-frequency sweeps for energetic laser runs.

Source: Sustained bright saw/FM tone. Grain: 16 ms; density 25; pitch 12 semitones. Filter: Resonant Peak, 4200 Hz.

## 11 Comb Shrapnel

Three fixed repeats into a 2 ms internal comb, for metallic glitch shards.

Source: Short noise hit or metallic percussion. Grain: 19 ms; density 21; pitch 0 semitones. Filter: Northern VA, 6500 Hz.

## 12 Terminal Fill

Authored acceleration from sixteenths to sixty-fourths, octave answers and an end gap.

Source: Dry FM/percussion loop; use for a one-bar fill. Grain: 23 ms; density 20; pitch 12 semitones. Filter: Acid Ladder, 5000 Hz.


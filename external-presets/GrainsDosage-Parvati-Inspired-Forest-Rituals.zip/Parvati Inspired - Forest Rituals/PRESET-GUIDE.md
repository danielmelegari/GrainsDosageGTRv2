# Parvati Inspired - Forest Rituals

12 individually authored effect presets for GrainsDosage 0.13.22.
Suggested tempo: 145–155 BPM. Original forest-psy designs; not an official Parvati Records product or a recreation of specific tracks.

All enabled modules with a Mix control use 100%; disabled module mixes are 0%. Master mix is 100%. Filter and Gater have no separate mix. No modulation targets any mix. Limiter enabled at -6 dBFS.

Use on a separate synth/percussion/FX track, preferably with a dry source and some headroom. These process incoming audio; they do not generate a forest or laser sound from silence. Avoid the kick/bass bus for the first audition. Let audio play for a bar to fill the buffers. Pitches depend on your source.

The rhythm masks, LFO waves, rates and pitch phrases are authored, not randomized. Granular scheduling and Reslice retain their inherent engine behavior; fixed Reslice seeds/ranges constrain their variation.

## 01 Root Conversation

Rounded vowel movement and a 3-3-2 gate; grounded forest call-and-response.

Source: Dry FM or woody percussion loop. Grain: 68 ms; density 9; pitch -7 semitones. Filter: Formant O, 850 Hz.

## 02 Bark Scratcher

Close, rough grain clusters with a narrow moving spectral band.

Source: Scrapes, shakers or short noise hits. Grain: 24 ms; density 12; pitch -12 semitones. Filter: Low + Band, 1250 Hz.

## 03 Night Insects

High chattering grains; fast small formant motion over an uneven pulse.

Source: Dry metallic ticks or an FM stab. Grain: 19 ms; density 17; pitch 12 semitones. Filter: Formant I, 1750 Hz.

## 04 Hollow Trunk

Low comb ringing and long grains; tuned around G3 rather than a bright laser.

Source: Woodblocks or a short broadband hit. Grain: 92 ms; density 7; pitch -12 semitones. Filter: Comb +, 196 Hz.

## 05 Vine Dialogue

Two-bar vowel sweep with sparse repeated answers at the phrase ends.

Source: Midrange FM phrase or dry vocal fragment. Grain: 46 ms; density 11; pitch 0 semitones. Filter: Formant A, 940 Hz.

## 06 Spore Spiral

Slow phaser orbit and bounded lookback movement; an evolving bed without reverb wash.

Source: Sustained rough synth or textured field recording. Grain: 110 ms; density 8; pitch 7 semitones. Filter: Phaser 8, 720 Hz.

## 07 Ritual Feet

Short dark grains and a fixed interlocking gate with full-length attack spaces.

Source: Dry hand-percussion loop. Grain: 38 ms; density 10; pitch -5 semitones. Filter: Transistor Ladder, 1600 Hz.

## 08 Understory Cuts

Controlled two-repeat cuts into an E vowel; fixed pitch and source-area limits.

Source: Dry FM rhythm or woody loop. Grain: 58 ms; density 9; pitch 0 semitones. Filter: Formant E, 1100 Hz.

## 09 Swamp Call

Low throaty U vowel and a slow breathing cutoff, for sparse replies.

Source: Short saw/FM stab. Grain: 135 ms; density 6; pitch -19 semitones. Filter: Formant U, 700 Hz.

## 10 Canopy Echo

Dedicated fully wet short reverb texture; leave gaps between source hits.

Source: Sparse wood or bell hits. Grain: 75 ms; density 8; pitch 7 semitones. Filter: Northern VA, 2600 Hz.

## 11 Mycelium Pulse

Damped acid motion with sixteenth-note gates; rhythmic forest lead processing.

Source: Dry midrange saw or FM loop. Grain: 31 ms; density 14; pitch 0 semitones. Filter: Acid Ladder, 1800 Hz.

## 12 Deep Clearing

Dedicated fully wet dark space for transitions, with a four-bar cutoff cycle.

Source: Textured drone or sustained vocal. Grain: 180 ms; density 6; pitch -12 semitones. Filter: Low + High, 1300 Hz.

